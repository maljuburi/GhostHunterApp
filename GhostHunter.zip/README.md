Ghost Hunter Mobile Application
